#ifndef VCHELPERS_H
#define VCHELPERS_H

#include <stdio.h>
#include "VCParser.h"

// Remove trailing newline and carriage return characters from a string.
void trimNewline(char *str);

// Reads the given line and any subsequent folded lines from fp; returns a newly allocated unfolded string.
char* unfoldLine(FILE *fp, char *line);

// Parses a property line (already unfolded) into a new Property structure.
Property* parseProperty(char* line);

// Parses a date/time string into a DateTime structure (numeric or full date/time strings).
DateTime* parseDateTime(char* dtStr);

// Parses a date/time string as text (when VALUE=text is specified).
DateTime* parseDateTimeAsText(char* dtStr);

#endif
