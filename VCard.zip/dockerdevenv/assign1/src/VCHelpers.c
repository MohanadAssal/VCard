
#include "VCHelpers.h"    
#include <stdlib.h>       
#include <string.h>       
#include <ctype.h>       

// ----------------------------------------------------------------
// Function: trimNewline
// Purpose: Remove any trailing newline ('\n') or carriage return ('\r')
//          characters from a string.
// ----------------------------------------------------------------

void trimNewline(char *str) {
    
    if(str == NULL) return;         // If the string pointer is NULL, do nothing.
    
    int len = strlen(str);          // Get the length of the string.
    
    // While the string has characters and the last character is '\n' or '\r'
    
    while(len > 0 && (str[len-1] == '\n' || str[len-1] == '\r')) {
        
        str[len-1] = '\0';          // Replace the newline/carriage return with a null terminator.
        
        len--;                      // Decrease the length.
        
    }
    
}



// ----------------------------------------------------------------

// Function: unfoldLine

// Purpose: Read a line and any subsequent "folded" lines (lines that

//          begin with a space or tab) from the file and combine them

//          into one continuous string.

// ----------------------------------------------------------------

char* unfoldLine(FILE *fp, char *line) {
    
    if(line == NULL) return NULL;   // If no line was passed, return NULL.
    
    trimNewline(line);              // Remove the trailing newline from the initial line.
    
    size_t totalLen = strlen(line) + 1; // Start with the length of the initial line + null terminator.
    
    char *result = strdup(line);    // Duplicate the initial line to start our result.
    
    char *nextLine = NULL;          // Will hold any subsequent lines.
    
    size_t len = 0;
    
    ssize_t read;
    
    // Read subsequent lines
    
    while((read = getline(&nextLine, &len, fp)) != -1) {
        
        // If the next line starts with a space or tab, it is a continuation (folded line).
        
        if(nextLine[0] == ' ' || nextLine[0] == '\t') {
            
            // Skip leading whitespace.
            
            char *trimmed = nextLine;
            
            while(*trimmed && (*trimmed == ' ' || *trimmed == '\t')) {
                
                trimmed++;          // Move the pointer past whitespace.
                
            }
            
            trimNewline(trimmed);   // Remove any newline characters from this part.
            
            totalLen += strlen(trimmed);  // Increase the total length needed.
            
            result = realloc(result, totalLen); // Reallocate memory for the result.
            
            strcat(result, trimmed);  // Append the trimmed text to the result.
            
        } else {
            
            // If the line does not start with whitespace, it's not a folded line.
            
            // Move the file pointer back to re-read this line later.
            
            fseek(fp, -read, SEEK_CUR);
            
            break;
            
        }
        
    }
    
    free(nextLine);                 // Free the temporary line buffer.
    
    return result;                  // Return the combined (unfolded) string.
    
}



// ----------------------------------------------------------------

// Function: parseProperty

// Purpose: Parse an unfolded property line into a Property structure.

//          A property line is expected to have a header and a value separated by a colon.

//          The header may include a group (separated by a dot) and parameters (separated by semicolons).

// ----------------------------------------------------------------

Property* parseProperty(char* line) {
    
    if(line == NULL) return NULL;   // Return NULL if the line is NULL.
    
    char *colonPos = strchr(line, ':');  // Find the colon that separates the header from the value.
    
    if(colonPos == NULL) return NULL;     // If no colon is found, the property is invalid.
    
    *colonPos = '\0';               // Terminate the header string at the colon.
    
    char *header = line;            // The header part (before the colon).
    
    char *valuePart = colonPos + 1; // The value part (after the colon).
    
    
    
    if(strlen(header) == 0) return NULL;  // If the header is empty, return NULL.
    
    
    
    // Allocate memory for a new Property structure.
    
    Property *prop = malloc(sizeof(Property));
    
    if(prop == NULL) return NULL;
    
    // Initialize the fields:
    
    prop->group = strdup("");       // Start with an empty group.
    
    prop->name = NULL;              // Will be set later.
    
    // Initialize linked lists for parameters and values.
    
    prop->parameters = initializeList(parameterToString, deleteParameter, compareParameters);
    
    prop->values = initializeList(valueToString, deleteValue, compareValues);
    
    
    
    // Check if a group is specified (group.property format, indicated by a dot).
    
    char *dotPos = strchr(header, '.');
    
    if(dotPos != NULL) {
        
        *dotPos = '\0';           // Split at the dot.
        
        free(prop->group);
        
        prop->group = strdup(header); // The part before the dot is the group.
        
        header = dotPos + 1;      // The remaining part is the property name (with possible parameters).
        
    }
    
    
    
    // Check for parameters in the header (indicated by semicolons).
    
    char *semiPos = strchr(header, ';');
    
    if(semiPos != NULL) {
        
        *semiPos = '\0';          // Split off the property name.
        
        if(strlen(header) == 0) { // If the property name is empty, it's an error.
        
            free(prop->group);
            
            freeList(prop->parameters);
            
            freeList(prop->values);
            
            free(prop);
            
            return NULL;
            
        }
        
        prop->name = strdup(header);  // Set the property name.
        
        // The remainder after the semicolon contains parameters.
        
        char *params = semiPos + 1;
        
        char *token = params;
        
        char *next;
        
        // Process each parameter (expected in key=value format) separated by semicolons.
        
        while(token != NULL && strlen(token) > 0) {
            
            next = strchr(token, ';');
            
            if(next != NULL) {
                
                *next = '\0';     // Terminate the current parameter string.
                
            }
            
            // Each parameter must contain an equal sign.
            
            char *equalPos = strchr(token, '=');
            
            if(equalPos == NULL || strlen(token) == 0 || strlen(equalPos + 1) == 0) {
                
                // If the parameter format is wrong, clean up and return NULL.
                
                free(prop->name);
                
                free(prop->group);
                
                freeList(prop->parameters);
                
                freeList(prop->values);
                
                free(prop);
                
                return NULL;
                
            }
            
            *equalPos = '\0';       // Split into key and value.
            
            // Allocate a new Parameter structure.
            
            Parameter *param = malloc(sizeof(Parameter));
            
            if(param == NULL) return NULL;
            
            param->name = strdup(token);         // Parameter key.
            
            param->value = strdup(equalPos + 1);   // Parameter value.
            
            insertBack(prop->parameters, param);   // Add the parameter to the list.
            
            if(next != NULL) {
                
                token = next + 1;    // Move to the next parameter.
                
            } else {
                
                token = NULL;
                
            }
            
        }
        
    } else {
        
        // If no parameters, the header is just the property name.
        
        prop->name = strdup(header);
        
        if(strlen(prop->name) == 0) {
            
            // If property name ends up empty, clean up and return NULL.
            
            free(prop->name);
            
            free(prop->group);
            
            freeList(prop->parameters);
            
            freeList(prop->values);
            
            free(prop);
            
            return NULL;
            
        }
        
    }
    
    
    
    // Now, split the value part into one or more tokens separated by semicolons.
    
    char *valToken = valuePart;
    
    char *valNext;
    
    while(valToken != NULL) {
        
        valNext = strchr(valToken, ';'); // Look for the next semicolon.
        
        if(valNext != NULL) {
            
            *valNext = '\0';   // Terminate the current token.
            
        }
        
        // Duplicate the token and insert it into the values list.
        
        char *valCopy = strdup(valToken);
        
        insertBack(prop->values, valCopy);
        
        if(valNext != NULL) {
            
            valToken = valNext + 1;  // Move to the next token.
            
        } else {
            
            valToken = NULL;
            
        }
        
    }
    
    return prop;  // Return the parsed Property.
    
}



// ----------------------------------------------------------------

// Function: parseDateTime

// Purpose: Convert a date/time string (from a vCard property) into a DateTime structure.

//          If the string is a truncated date (e.g., starts with "--"), store the entire string in the 'date' field.

// ----------------------------------------------------------------

DateTime* parseDateTime(char* dtStr) {
    
    if(dtStr == NULL) return NULL;
    
    DateTime *dt = malloc(sizeof(DateTime));
    
    if(dt == NULL) return NULL;
    
    dt->UTC = false;     // By default, assume not UTC.
    
    dt->isText = false;  // This is a numeric date/time.
    
    // Check for a truncated date format that begins with "--".
    
    if(strlen(dtStr) >= 2 && dtStr[0]=='-' && dtStr[1]=='-') {
        
        dt->date = strdup(dtStr);  // Store the whole string (e.g., "--0203").
        
        dt->time = strdup("");       // No time part.
        
        dt->text = strdup("");
        
        return dt;
        
    }
    
    // Initialize fields to empty strings.
    
    dt->date = strdup("");
    
    dt->time = strdup("");
    
    dt->text = strdup("");
    
    
    
    // Look for the 'T' character, which separates date and time.
    
    char *tPos = strchr(dtStr, 'T');
    
    if(tPos != NULL) {
        
        *tPos = '\0';              // Terminate the date portion.
        
        free(dt->date);
        
        dt->date = strdup(dtStr);   // Store the date portion.
        
        char *timeStr = tPos + 1;     // The remaining string is the time.
        
        size_t len = strlen(timeStr);
        
        // If the time ends with a 'Z', it indicates UTC time.
        
        if(len > 0 && timeStr[len - 1] == 'Z') {
            
            dt->UTC = true;
            
            timeStr[len - 1] = '\0'; // Remove the trailing 'Z'.
            
        }
        
        free(dt->time);
        
        dt->time = strdup(timeStr); // Store the time.
        
    } else {
        
        // If no 'T' is present, treat the entire string as a date.
        
        free(dt->date);
        
        dt->date = strdup(dtStr);
        
        free(dt->time);
        
        dt->time = strdup("");
        
    }
    
    return dt;
    
}



// ----------------------------------------------------------------

// Function: parseDateTimeAsText

// Purpose: Convert a date/time string specified as text (when a parameter says VALUE=text)

//          into a DateTime structure. In this case, the 'isText' flag is set, and the text

//          value is stored in the 'text' field.


// ----------------------------------------------------------------

DateTime* parseDateTimeAsText(char* dtStr) {

    if(dtStr == NULL) return NULL;

    DateTime *dt = malloc(sizeof(DateTime));

    if(dt == NULL) return NULL;

    dt->UTC = false;      // Text values are not considered UTC.

    dt->isText = true;    // Mark this DateTime as text.

    dt->date = strdup("");  // Date and time fields remain empty.

    dt->time = strdup("");

    free(dt->text);

    dt->text = strdup(dtStr);  // Store the entire string in 'text'.

    return dt;

}


