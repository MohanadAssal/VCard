
#include "VCParser.h"   
#include "VCHelpers.h"  
#include <string.h>     
#include <ctype.h>      

// ----------------------------------------------------------------
// Function: createCard
// Purpose: Read a vCard file, validate its format, parse its properties,
//          and build a Card structure representing the vCard.
// ----------------------------------------------------------------
VCardErrorCode createCard(char* fileName, Card** newCardObject) {
    // Check that the file name is not NULL or empty.
    if (fileName == NULL || strlen(fileName) == 0) {
        return INV_FILE;
    }
    // Verify the file has a proper extension (.vcf or .vcard).
    char *dot = strrchr(fileName, '.');
    if (!dot || (strcmp(dot, ".vcf") != 0 && strcmp(dot, ".vcard") != 0)) {
        return INV_FILE;
    }
    
    // Open the file for reading.
    FILE *fp = fopen(fileName, "r");
    if (fp == NULL) {
        return INV_FILE;
    }
    
    char *line = NULL;
    size_t len = 0;
    ssize_t read;
    
    // Read the first line; it should be "BEGIN:VCARD".
    read = getline(&line, &len, fp);
    if (read == -1) {
        fclose(fp);
        return INV_CARD;
    }
    // Optionally check for CRLF endings (if required by the spec).
    if (read < 2 || line[read-2] != '\r') {
        free(line);
        fclose(fp);
        return INV_CARD;
    }
    trimNewline(line);              // Remove newline characters.
    if (strcmp(line, "BEGIN:VCARD") != 0) {
        free(line);
        fclose(fp);
        return INV_CARD;
    }
    
    // Read the second line; it should be "VERSION:4.0".
    read = getline(&line, &len, fp);
    if (read == -1) {
        free(line);
        fclose(fp);
        return INV_CARD;
    }
    if (read < 2 || line[read-2] != '\r') {
        free(line);
        fclose(fp);
        return INV_CARD;
    }
    trimNewline(line);
    if (strcmp(line, "VERSION:4.0") != 0) {
        free(line);
        fclose(fp);
        return INV_CARD;
    }
    
    // Allocate a new Card structure.
    Card *card = malloc(sizeof(Card));
    if (card == NULL) {
        free(line);
        fclose(fp);
        return OTHER_ERROR;
    }
    // Initialize the Card fields.
    card->fn = NULL; // The FN property is mandatory.
    // Create a new linked list for any additional properties.
    card->optionalProperties = initializeList(propertyToString, deleteProperty, compareProperties);
    card->birthday = NULL;    // Optional birthday.
    card->anniversary = NULL; // Optional anniversary.
    
    bool endFound = false; // Flag to track whether the "END:VCARD" tag is found.
    // Read through the remaining lines until we reach the "END:VCARD" line.
    while ((read = getline(&line, &len, fp)) != -1) {
        // Use unfoldLine() to combine any folded lines into one.
        char *unfoldedLine = unfoldLine(fp, line);
        trimNewline(unfoldedLine);
        // Check if this line signals the end of the vCard.
        if (strcmp(unfoldedLine, "END:VCARD") == 0) {
            endFound = true;
            free(unfoldedLine);
            break;
        }
        
        // Parse the unfolded line into a Property structure.
        Property *prop = parseProperty(unfoldedLine);
        if (prop == NULL) {
            // If parsing fails, clean up and return an invalid property error.
            free(unfoldedLine);
            deleteCard(card);
            free(line);
            fclose(fp);
            return INV_PROP;
        }
        
        // Handle properties based on their names.
        if (strcmp(prop->name, "FN") == 0) {
            // If this is the FN property, and we haven't set it yet, use it.
            if (card->fn == NULL) {
                card->fn = prop;
            } else {
                // If there is already an FN, add this as an additional property.
                insertBack(card->optionalProperties, prop);
            }
        } else if (strcmp(prop->name, "BDAY") == 0) {
            // If the property is BDAY, parse it as a date/time.
            DateTime *dt = NULL;
            bool isText = false;
            // Check if the BDAY property has a parameter indicating VALUE=text.
            ListIterator iter = createIterator(prop->parameters);
            Parameter *param;
            while ((param = nextElement(&iter)) != NULL) {
                if (strcmp(param->name, "VALUE") == 0 && strcmp(param->value, "text") == 0) {
                    isText = true;
                    break;
                }
            }
            // Parse accordingly.
            if (isText)
                dt = parseDateTimeAsText((char*)getFromFront(prop->values));
            else
                dt = parseDateTime((char*)getFromFront(prop->values));
            if (dt == NULL) {
                free(unfoldedLine);
                deleteCard(card);
                free(line);
                fclose(fp);
                return INV_DT;
            }
            // Save the parsed birthday into the Card.
            card->birthday = dt;
            // For dedicated properties, we do not insert them into the optional properties list.
            deleteProperty(prop); // Free the temporary property.
        } else if (strcmp(prop->name, "ANNIVERSARY") == 0) {
            // Handle the ANNIVERSARY property similarly to BDAY.
            DateTime *dt = NULL;
            bool isText = false;
            ListIterator iter = createIterator(prop->parameters);
            Parameter *param;
            while ((param = nextElement(&iter)) != NULL) {
                if (strcmp(param->name, "VALUE") == 0 && strcmp(param->value, "text") == 0) {
                    isText = true;
                    break;
                }
            }
            if (isText)
                dt = parseDateTimeAsText((char*)getFromFront(prop->values));
            else
                dt = parseDateTime((char*)getFromFront(prop->values));
            if (dt == NULL) {
                free(unfoldedLine);
                deleteCard(card);
                free(line);
                fclose(fp);
                return INV_DT;
            }
            card->anniversary = dt;
            deleteProperty(prop);
        } else {
            // For all other properties, simply add them to the Card's list.
            insertBack(card->optionalProperties, prop);
        }
        free(unfoldedLine); // Free the memory used for the unfolded line.
    }
    
    free(line);      // Free the line buffer.
    fclose(fp);      // Close the file.
    
    // If we never encountered "END:VCARD" or didn't get an FN property, the card is invalid.
    if (!endFound || card->fn == NULL) {
        deleteCard(card);
        return INV_CARD;
    }
    
    // Return the successfully parsed Card.
    *newCardObject = card;
    return OK;
}

// ----------------------------------------------------------------
// Function: deleteCard
// Purpose: Free all dynamically allocated memory in a Card structure,
//          including its FN property, optional properties, and any date/time structures.
// ----------------------------------------------------------------
void deleteCard(Card* obj) {
    if (obj == NULL) return;   // Do nothing if the Card is NULL.
    if (obj->fn != NULL) {
        deleteProperty(obj->fn);  // Free the FN property.
    }
    if (obj->optionalProperties != NULL) {
        freeList(obj->optionalProperties);  // Free the list of optional properties.
    }
    if (obj->birthday != NULL) {
        deleteDate(obj->birthday);  // Free the birthday DateTime.
    }
    if (obj->anniversary != NULL) {
        deleteDate(obj->anniversary);  // Free the anniversary DateTime.
    }
    free(obj);  // Finally, free the Card structure itself.
}

// ----------------------------------------------------------------
// Function: cardToString
// Purpose: Return a human-readable string representation of a Card.
//          Here, we simply return the FN property for simplicity.
// ----------------------------------------------------------------
char* cardToString(const Card* obj) {
    if (obj == NULL) {
        char *str = malloc(50);
        strcpy(str, "Card: NULL");
        return str;
    }
    // Get the first value of the FN property.
    char *fnVal = (char*)getFromFront(obj->fn->values);
    char *str = malloc(100);
    sprintf(str, "Card: FN=%s", fnVal ? fnVal : "None");
    return str;
}

// ----------------------------------------------------------------
// Function: errorToString
// Purpose: Convert an error code (from VCardErrorCode) into a human-readable string.
// ----------------------------------------------------------------
char* errorToString(VCardErrorCode err) {
    char *str = malloc(50);
    switch(err) {
        case OK:
            strcpy(str, "OK");
            break;
        case INV_FILE:
            strcpy(str, "Invalid file");
            break;
        case INV_CARD:
            strcpy(str, "Invalid card");
            break;
        case INV_PROP:
            strcpy(str, "Invalid property");
            break;
        case INV_DT:
            strcpy(str, "Invalid date/time");
            break;
        case WRITE_ERROR:
            strcpy(str, "Write error");
            break;
        default:
            strcpy(str, "Other error");
            break;
    }
    return str;
}

/* ----------------------------------------------------------------
   List Helper Functions
   These functions are used as callbacks by the linked list API to
   delete, compare, and print data stored in the lists.
   ---------------------------------------------------------------- */

// Free a Property structure and its associated memory.
void deleteProperty(void* toBeDeleted) {
    if (toBeDeleted == NULL) return;
    Property *prop = (Property*)toBeDeleted;
    if (prop->name) free(prop->name);
    if (prop->group) free(prop->group);
    if (prop->parameters) freeList(prop->parameters);
    if (prop->values) freeList(prop->values);
    free(prop);
}

// Compare two Property structures by their names.
int compareProperties(const void* first, const void* second) {
    const Property *p1 = (const Property*)first;
    const Property *p2 = (const Property*)second;
    return strcmp(p1->name, p2->name);
}

// Return a string representation of a Property (for debugging).
char* propertyToString(void* prop) {
    if (prop == NULL) return strdup("NULL");
    Property *p = (Property*)prop;
    char *str = malloc(256);
    sprintf(str, "Property: group='%s', name='%s'", p->group, p->name);
    return str;
}

// Free a Parameter structure.
void deleteParameter(void* toBeDeleted) {
    if (toBeDeleted == NULL) return;
    Parameter *param = (Parameter*)toBeDeleted;
    if (param->name) free(param->name);
    if (param->value) free(param->value);
    free(param);
}

// Compare two Parameter structures by their names.
int compareParameters(const void* first, const void* second) {
    const Parameter *p1 = (const Parameter*)first;
    const Parameter *p2 = (const Parameter*)second;
    return strcmp(p1->name, p2->name);
}

// Return a string representation of a Parameter.
char* parameterToString(void* param) {
    if (param == NULL) return strdup("NULL");
    Parameter *p = (Parameter*)param;
    char *str = malloc(256);
    sprintf(str, "Parameter: %s=%s", p->name, p->value);
    return str;
}

// Free a value (which is a string) from the values list.
void deleteValue(void* toBeDeleted) {
    if (toBeDeleted != NULL) {
        free(toBeDeleted);
    }
}

// Compare two values (strings) using strcmp.
int compareValues(const void* first, const void* second) {
    const char *s1 = (const char*)first;
    const char *s2 = (const char*)second;
    return strcmp(s1, s2);
}

// Return a string representation of a value (string).
char* valueToString(void* val) {
    if (val == NULL) return strdup("NULL");
    return strdup((char*)val);
}

// Free a DateTime structure and its associated memory.
void deleteDate(void* toBeDeleted) {
    if (toBeDeleted == NULL) return;
    DateTime *dt = (DateTime*)toBeDeleted;
    if (dt->date) free(dt->date);
    if (dt->time) free(dt->time);
    if (dt->text) free(dt->text);
    free(dt);
}

// Compare two DateTime structures by comparing their 'date' strings.
int compareDates(const void* first, const void* second) {
    const DateTime *d1 = (const DateTime*)first;
    const DateTime *d2 = (const DateTime*)second;
    return strcmp(d1->date, d2->date);
}

// Return a string representation of a DateTime.
char* dateToString(void* date) {
    if (date == NULL) return strdup("NULL");
    DateTime *dt = (DateTime*)date;
    char *str = malloc(256);
    if (dt->isText)
        sprintf(str, "DateTime (text): %s", dt->text);
    else
        sprintf(str, "DateTime: date=%s, time=%s%s", dt->date, dt->time, dt->UTC ? "Z" : "");
    return str;
}
